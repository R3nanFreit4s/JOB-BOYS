import React from 'react';
import {Button} from '@rneui/themed';

const Multiplicar = ({numero1, numero2, setResultado}) => {
  // Função para calcular a multiplicação dos números
  const calcularMultiplicacao = () => {
    // Converte os números de string para float e realiza a multiplicação
    const mult = parseFloat(numero1) * parseFloat(numero2);
    // Atualiza o estado 'resultado' com o valor da multiplicação convertido para string
    setResultado(mult.toString());
  };

  return (
    <Button
      containerStyle={{
        width: 40,
        height: 45,
        marginHorizontal: 2,
              }}
      size="sm" color="#262626" title="Multiplicar"
      onPress={calcularMultiplicacao}>x
      </Button>
  )
}

export default Multiplicar;