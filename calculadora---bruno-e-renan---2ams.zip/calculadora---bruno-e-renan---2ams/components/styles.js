import {StyleSheet} from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'black',
  },

  input: {
    color: '#C4C4C4',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
    width: '90%',
  },

  resultado: {
    alignItems: 'center',
    textAlign: 'center',
    marginTop: 5,
    fontSize: 15,
    color: '#C4C4C4'
  },
  
  botoes: {
    flexDirection: 'row',
    marginEnd: 0,
    }

});