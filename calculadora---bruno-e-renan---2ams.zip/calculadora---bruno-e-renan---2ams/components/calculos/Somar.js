import React from 'react';
import {Button} from '@rneui/themed';

const Somar = ({numero1, numero2, setResultado}) => {
 // Função para calcular a soma dos números
  const calcularSoma = () => {
    // Converte os números de string para float e realiza a soma
    const soma = parseFloat(numero1) + parseFloat(numero2);
    // Atualiza o estado 'resultado' com o valor da soma convertido para string
    setResultado(soma.toString());
  };

  return (
  <Button
    containerStyle={{
      width: 40,
      height: 45,
      marginHorizontal: 2,
      }}
      size="sm" color="#262626" spacing={100} title="Somar"
      onPress={calcularSoma}>+
  </Button>
  )
};

export default Somar;