import React from 'react';
import {Button} from '@rneui/themed';

const Clean = ({setNumero1, setNumero2, setResultado}) => {
  // Função para calcular a multiplicação dos números
  const limparInputs = () => {
    setNumero1('');
    setNumero2('');
    setResultado('');
  }

  return (
    <Button
      containerStyle={{
        width: 40,
        height: 45,
        marginHorizontal: 2,
              }}
      size="sm" color="red" title="Limpar"
      onPress={limparInputs}>C
      </Button>
  )
}

export default Clean;