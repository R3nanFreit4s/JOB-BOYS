import React from 'react';
import {Button} from '@rneui/themed';

const Subtrair = ({numero1, numero2, setResultado}) => {
  // Função para calcular a subtração dos números
  const calcularSubtracao = () => {
    // Converte os números de string para float e realiza a subtração
    const sub = parseFloat(numero1) - parseFloat(numero2);
    // Atualiza o estado 'resultado' com o valor da subtração convertido para string
    setResultado(sub.toString());
  };

  return (
    <Button
      containerStyle={{
        width: 40,
        height: 45,
        marginHorizontal: 2,
              }}
      size="sm" color="#262626" title="Subtrair"
      onPress={calcularSubtracao}>-
      </Button>
  )
}

export default Subtrair;