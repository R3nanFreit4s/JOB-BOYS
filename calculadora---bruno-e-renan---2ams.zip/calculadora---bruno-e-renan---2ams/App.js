import React, { useState } from 'react';
import { View, TextInput, Text } from 'react-native';
import Somar from './components/calculos/Somar';
import Subtrair from './components/calculos/Subtrair';
import Multiplicar from './components/calculos/Multiplicar';
import Dividir from './components/calculos/Dividir';
import Clean from './components/Clean';
import styles from './components/styles';

export const Calculadora = () => {
  // Definindo estados para armazenar os números e o resultado da soma
  const [numero1, setNumero1] = useState(''); // Estado para o primeiro número
  const [numero2, setNumero2] = useState(''); // Estado para o segundo número
  const [resultado, setResultado] = useState(''); // Estado para o resultado da soma

  return (
    <View style={styles.container}>
      {/* Campo de entrada para o primeiro número */}
      <TextInput
        style={styles.input}
        placeholder="Digite o primeiro número"
        placeholderTextColor="#787878"
        keyboardType="numeric"
        value={numero1}
        onChangeText={setNumero1} // Atualiza o estado 'numero1' conforme o texto é digitado
      />
      {/* Campo de entrada para o segundo número */}
      <TextInput
        style={styles.input}
        placeholder="Digite o segundo número"
        placeholderTextColor="#787878"
        keyboardType="numeric"
        value={numero2}
        onChangeText={setNumero2} // Atualiza o estado 'numero2' conforme o texto é digitado
      />
      
      {/* Botões das operações matemáticas */}
      <View style={styles.botoes}>

      <Clean
      setNumero1={setNumero1}
      setNumero2={setNumero2}
      setResultado={setResultado}
      /> {/* Limpar */}

      <Somar
      numero1={numero1}
      numero2={numero2}
      setResultado={setResultado}
      /> {/* Soma */}

      <Subtrair
      numero1={numero1}
      numero2={numero2}
      setResultado={setResultado}
      /> {/* Subtração */}

      <Multiplicar
      numero1={numero1}
      numero2={numero2}
      setResultado={setResultado}
      /> {/* Multiplicação */}

      <Dividir
      numero1={numero1}
      numero2={numero2}
      setResultado={setResultado}
      /> {/* Divisão */}
      
      </View>

      {/* Exibe o resultado da soma */}
      <Text style={styles.resultado}>Resultado: {resultado}</Text>
    </View>
  );
};

export default Calculadora;
