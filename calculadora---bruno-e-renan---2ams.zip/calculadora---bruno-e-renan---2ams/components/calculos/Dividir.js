import React from 'react';
import {Button} from '@rneui/themed';

const Dividir = ({numero1, numero2, setResultado}) => {
  // Função para calcular a divisão dos números
  const calcularDivisao = () => {
    if (numero1 != 0 && numero2 != 0){
      // Converte os números de string para float e realiza a divisão
    const div = parseFloat(numero1) / parseFloat(numero2);
    // Atualiza o estado 'resultado' com o valor da divisão convertido para string
    setResultado(div.toString());
    }

    else {
      const erro = "Não é possível realizar divisões com zero";
      setResultado(erro.toString());
    }
  };
  
  return (
    <Button
      containerStyle={{
        width: 40,
        height: 45,
        marginHorizontal: 2,
              }}
      size="sm" color="#262626" title="Dividir"
      onPress={calcularDivisao}>/
      </Button>
  )
}

export default Dividir;